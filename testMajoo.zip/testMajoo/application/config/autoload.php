<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$autoload['packages'] = array();
$autoload['libraries'] = array('database','session','upload');
$autoload['drivers'] = array();
$autoload['helper'] = array('form','string','url');
$autoload['config'] = array();
$autoload['language'] = array();
$autoload['model'] = array();
